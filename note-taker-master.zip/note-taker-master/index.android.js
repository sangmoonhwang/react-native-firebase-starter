import {AppRegistry} from 'react-native';
import app from './app/index';

AppRegistry.registerComponent('NoteTaker', () => app);
export default app;
