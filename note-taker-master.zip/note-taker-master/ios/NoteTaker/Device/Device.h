//
//  Device.h
//  NoteTaker
//
//  Created by Atul R on 14/09/17.
//  Copyright © 2017 Facebook. All rights reserved.
//
#import <React/RCTBridgeModule.h>

@interface Device : NSObject <RCTBridgeModule>
@end
