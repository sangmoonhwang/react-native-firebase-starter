import Router from '../index';
Router.router.getStateForAction = jest.fn();

module.exports = Router;
