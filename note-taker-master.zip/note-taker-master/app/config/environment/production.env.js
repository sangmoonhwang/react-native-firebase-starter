module.exports = {
  ENV: 'prod'
};
