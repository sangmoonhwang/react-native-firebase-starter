export default {
  HOME_noteTitle: 'नोट शीर्षक',
  HOME_pleaseTypeYourNote: 'कृपया नीचे अपना नोट लिखें',
  HOME_startTakingNotes: 'नोट्स लेना शुरू करें',
  HOME_save: 'सहेजें',
  HOME_characters: 'वर्ण',
  ABOUT_us: 'अधिक जानकारी',
  ABOUT_theApp: 'एप के बारे में',
  ABOUT_theCreators: 'रचनाकारों के बारे में',
  ABOUT_theAppDesc: 'एप के बारे में',
  ABOUT_theCreatorsDesc: 'रचनाकारों के बारे में',
  NOTES_heading: 'नोट्स',
  NOTES_title: 'शीर्षक',
  NOTES_content: 'विस्तार'
};
