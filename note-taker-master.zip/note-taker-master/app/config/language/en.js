export default {
  HOME_noteTitle: 'Note Title',
  HOME_pleaseTypeYourNote: 'Please type your note below',
  HOME_startTakingNotes: 'Start taking notes',
  HOME_save: 'Save',
  HOME_characters: 'chacters',
  ABOUT_us: 'About Us',
  ABOUT_theApp: 'About the app',
  ABOUT_theCreators: 'About the Creators',
  ABOUT_theAppDesc: 'About the app',
  ABOUT_theCreatorsDesc: 'About the Creators',
  NOTES_heading: 'Notes',
  NOTES_title: 'Title',
  NOTES_content: 'Content'
};
