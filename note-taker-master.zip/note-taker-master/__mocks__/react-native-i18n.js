import i18n from 'i18n-js';

export default i18n;

export const getLanguages = jest.mock();
